<?php
/**
 * Plugin Name: AGRO&PEÇAS App
 * Description: Sistema de aplicações para filtros e conversores AGRO&PEÇAS
 * Version: 2.0.0
 * Author: AGRO&PEÇAS
 * Author URI: https://agroepecas.com.br
 */

if (!defined('ABSPATH')) {
    exit;
}

define('AGROEPECAS_APP_URL', plugin_dir_url(__FILE__));
define('AGROEPECAS_APP_PATH', plugin_dir_path(__FILE__));
define('AGROEPECAS_APP_VERSION', '2.0.0');

class AgroepecasApp {
    
    public function __construct() {
        add_action('init', array($this, 'init'));
        register_activation_hook(__FILE__, array($this, 'activate'));
    }
    
    public function init() {
        add_shortcode('agroepecas_filtros', array($this, 'display_filtros'));
        add_shortcode('agroepecas_conversor', array($this, 'display_conversor'));
        
        // AJAX handlers com filtros cascata
        add_action('wp_ajax_agroepecas_get_data', array($this, 'ajax_get_data'));
        add_action('wp_ajax_agroepecas_filter_data', array($this, 'ajax_filter_data'));
        add_action('wp_ajax_agroepecas_get_dependent_options', array($this, 'ajax_get_dependent_options'));
        add_action('wp_ajax_nopriv_agroepecas_get_data', array($this, 'ajax_get_data'));
        add_action('wp_ajax_nopriv_agroepecas_filter_data', array($this, 'ajax_filter_data'));
        add_action('wp_ajax_nopriv_agroepecas_get_dependent_options', array($this, 'ajax_get_dependent_options'));
        
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('admin_menu', array($this, 'add_admin_menu'));
    }
    
    public function activate() {
        $this->verify_tables();
    }
    
    private function verify_tables() {
        global $wpdb;
        $required_tables = array('app_filtros', 'app_conversoes');
        
        foreach ($required_tables as $table) {
            $table_name = $wpdb->prefix . $table;
            $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table_name'") == $table_name;
            
            if (!$table_exists) {
                error_log("AGRO&PEÇAS App: Tabela $table_name não encontrada.");
            }
        }
    }
    
    public function enqueue_scripts() {
        global $post;
        
        if (is_a($post, 'WP_Post') && (
            has_shortcode($post->post_content, 'agroepecas_filtros') ||
            has_shortcode($post->post_content, 'agroepecas_conversor')
        )) {
            wp_enqueue_style('agroepecas-style', AGROEPECAS_APP_URL . 'assets/style.css', array(), AGROEPECAS_APP_VERSION);
            wp_enqueue_script('agroepecas-script', AGROEPECAS_APP_URL . 'assets/script.js', array('jquery'), AGROEPECAS_APP_VERSION, true);
            
            wp_localize_script('agroepecas-script', 'agroepecas_ajax', array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('agroepecas_nonce')
            ));
        }
    }
    
    public function display_filtros($atts) {
        return $this->render_app(
            'Aplicação de Filtros Para Máquinas Agrícolas',
            'app_filtros',
            'filtros'
        );
    }
    
    public function display_conversor($atts) {
        return $this->render_app(
            'Conversor de Medidas CARRARO',
            'app_conversoes',
            'conversor'
        );
    }
    
    private function render_app($titulo, $tabela, $tipo) {
        ob_start();
        ?>
        <div id="agroepecas-app" 
             class="agroepecas-app" 
             data-table="<?php echo esc_attr($tabela); ?>"
             data-tipo="<?php echo esc_attr($tipo); ?>">
            
            <!-- Header -->
            <header class="agroepecas-header">
                <div class="agroepecas-container">
                    <div class="agroepecas-header-content">
                        <div class="agroepecas-logo-container">
                            <img src="https://i.imgur.com/xqCuadH.png" 
                                 alt="AGRO&PEÇAS Logo" 
                                 class="agroepecas-logo"
                                 onerror="this.style.display='none';">
                        </div>
                        <h1 class="agroepecas-title"><?php echo esc_html($titulo); ?></h1>
                    </div>
                </div>
            </header>

            <!-- Main Content -->
            <main class="agroepecas-main">
                <div class="agroepecas-container">
                    <!-- Filters Section -->
                    <div class="agroepecas-filters-section">
                        <h2 class="agroepecas-section-title">
                            <span class="agroepecas-icon">🔍</span>
                            <?php echo $tipo === 'conversor' ? 'Dados para Conversão' : 'Filtros de Busca'; ?>
                        </h2>
                        
                        <div class="agroepecas-filters-grid" id="agroepecas-filters-container">
                            <!-- Filtros carregados via JavaScript -->
                        </div>
                        
                        <div class="agroepecas-buttons">
                            <button id="agroepecas-btn-filtrar" class="agroepecas-btn agroepecas-btn-primary">
                                <span class="agroepecas-btn-icon">🔍</span>
                                <?php echo $tipo === 'conversor' ? 'Converter' : 'Filtrar'; ?>
                            </button>
                            <button id="agroepecas-btn-limpar" class="agroepecas-btn agroepecas-btn-secondary">
                                <span class="agroepecas-btn-icon">🗑️</span>
                                Limpar <?php echo $tipo === 'conversor' ? 'Campos' : 'Filtros'; ?>
                            </button>
                        </div>
                    </div>

                    <!-- Results Section -->
                    <div class="agroepecas-results-section">
                        <h2 class="agroepecas-section-title">
                            <span class="agroepecas-icon">📊</span>
                            Resultados
                        </h2>
                        
                        <div id="agroepecas-loading" class="agroepecas-loading" style="display: none;">
                            <div class="agroepecas-loading-spinner"></div>
                            <p>Carregando dados...</p>
                        </div>
                        
                        <div id="agroepecas-results-container">
                            <div class="agroepecas-table-container">
                                <table class="agroepecas-table">
                                    <thead id="agroepecas-table-head">
                                        <!-- Cabeçalhos carregados via JavaScript -->
                                    </thead>
                                    <tbody id="agroepecas-result-table">
                                        <!-- Dados carregados via JavaScript -->
                                    </tbody>
                                </table>
                            </div>
                            
                            <div id="agroepecas-initial-message" class="agroepecas-message">
                                <div class="agroepecas-message-icon">ℹ️</div>
                                <p>
                                    <?php 
                                    if ($tipo === 'conversor') {
                                        echo 'Preencha os campos acima e clique em "Converter" para ver os resultados.';
                                    } else {
                                        echo 'Selecione os filtros desejados e clique em "Filtrar" para ver os resultados.';
                                    }
                                    ?>
                                </p>
                            </div>
                            
                            <div id="agroepecas-no-results" class="agroepecas-message agroepecas-message-warning" style="display: none;">
                                <div class="agroepecas-message-icon">⚠️</div>
                                <p>Nenhum resultado encontrado para os <?php echo $tipo === 'conversor' ? 'valores informados' : 'filtros selecionados'; ?>.</p>
                            </div>
                            
                            <div class="agroepecas-result-info">
                                <span class="agroepecas-result-count">
                                    <strong id="agroepecas-result-count">0</strong> resultados encontrados
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </main>

            <!-- Footer -->
            <footer class="agroepecas-footer">
                <div class="agroepecas-container">
                    <p>&copy; <?php echo date('Y'); ?> AGRO&PEÇAS - Sistema de Aplicações | Desenvolvido com ❤️ para o agronegócio</p>
                </div>
            </footer>
        </div>
        <?php
        return ob_get_clean();
    }
    
    // AJAX Methods
    public function ajax_get_data() {
        check_ajax_referer('agroepecas_nonce', 'nonce');
        
        $table = sanitize_text_field($_POST['table']);
        global $wpdb;
        $table_name = $wpdb->prefix . $table;
        
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
            wp_send_json_error('Tabela não encontrada: ' . $table_name);
        }
        
        $columns = $wpdb->get_results("DESCRIBE $table_name", ARRAY_A);
        $results = $wpdb->get_results("SELECT * FROM $table_name ORDER BY id LIMIT 1000", ARRAY_A);
        
        wp_send_json_success(array(
            'columns' => $columns,
            'data' => $results
        ));
    }
    
    public function ajax_filter_data() {
        check_ajax_referer('agroepecas_nonce', 'nonce');
        
        $table = sanitize_text_field($_POST['table']);
        $filters = $_POST['filters'];
        
        global $wpdb;
        $table_name = $wpdb->prefix . $table;
        
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
            wp_send_json_error('Tabela não encontrada: ' . $table_name);
        }
        
        $where_conditions = array();
        $where_values = array();
        
        foreach ($filters as $key => $value) {
            if (!empty($value)) {
                $where_conditions[] = "`$key` = %s";
                $where_values[] = $value;
            }
        }
        
        $sql = "SELECT * FROM $table_name";
        if (!empty($where_conditions)) {
            $sql .= " WHERE " . implode(' AND ', $where_conditions);
        }
        $sql .= " ORDER BY id LIMIT 1000";
        
        if (!empty($where_values)) {
            $results = $wpdb->get_results($wpdb->prepare($sql, $where_values), ARRAY_A);
        } else {
            $results = $wpdb->get_results($sql, ARRAY_A);
        }
        
        wp_send_json_success($results);
    }
    
    public function ajax_get_dependent_options() {
        check_ajax_referer('agroepecas_nonce', 'nonce');
        
        $table = sanitize_text_field($_POST['table']);
        $column = sanitize_text_field($_POST['column']);
        $filters = $_POST['filters'];
        
        global $wpdb;
        $table_name = $wpdb->prefix . $table;
        
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
            wp_send_json_error('Tabela não encontrada: ' . $table_name);
        }
        
        $where_conditions = array();
        $where_values = array();
        
        foreach ($filters as $key => $value) {
            if (!empty($value) && $key !== $column) {
                $where_conditions[] = "`$key` = %s";
                $where_values[] = $value;
            }
        }
        
        $sql = "SELECT DISTINCT `$column` FROM `$table_name` WHERE `$column` IS NOT NULL AND `$column` != ''";
        if (!empty($where_conditions)) {
            $sql .= " AND " . implode(' AND ', $where_conditions);
        }
        $sql .= " ORDER BY `$column`";
        
        if (!empty($where_values)) {
            $results = $wpdb->get_col($wpdb->prepare($sql, $where_values));
        } else {
            $results = $wpdb->get_col($sql);
        }
        
        wp_send_json_success($results);
    }
    
    public function add_admin_menu() {
        add_menu_page(
            'AGRO&PEÇAS Apps',
            'AGRO&PEÇAS Apps',
            'manage_options',
            'agroepecas-app',
            array($this, 'admin_page'),
            'dashicons-admin-tools',
            30
        );
    }
    
    public function admin_page() {
        global $wpdb;
        ?>
        <div class="wrap">
            <h1>🚜 AGRO&PEÇAS - Sistema de Aplicações</h1>
            
            <div class="card">
                <h2>🔧 Shortcodes Disponíveis</h2>
                <table class="widefat">
                    <thead>
                        <tr>
                            <th>Shortcode</th>
                            <th>Descrição</th>
                            <th>Tabela</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><code>[agroepecas_filtros]</code></td>
                            <td>Sistema de Filtros para Máquinas Agrícolas</td>
                            <td>app_filtros</td>
                        </tr>
                        <tr>
                            <td><code>[agroepecas_conversor]</code></td>
                            <td>Conversor de Medidas CARRARO</td>
                            <td>app_conversoes</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            
            <div class="card">
                <h2>📊 Status das Tabelas</h2>
                <?php
                $tables = array(
                    'app_filtros' => 'Sistema de Filtros',
                    'app_conversoes' => 'Sistema de Conversão'
                );
                
                foreach ($tables as $table => $name) {
                    $table_name = $wpdb->prefix . $table;
                    $exists = $wpdb->get_var("SHOW TABLES LIKE '$table_name'") == $table_name;
                    $count = $exists ? $wpdb->get_var("SELECT COUNT(*) FROM $table_name") : 0;
                    
                    echo '<p>';
                    echo $exists ? '✅' : '❌';
                    echo ' <strong>' . $name . '</strong> (' . $table . '): ';
                    echo $exists ? "$count registros" : 'Tabela não encontrada';
                    echo '</p>';
                }
                ?>
            </div>
            
            <div class="card">
                <h2>ℹ️ Informações</h2>
                <p><strong>Versão:</strong> <?php echo AGROEPECAS_APP_VERSION; ?></p>
                <p><strong>Autor:</strong> AGRO&PEÇAS</p>
                <p><strong>Suporte:</strong> <a href="https://agroepecas.com.br" target="_blank">agroepecas.com.br</a></p>
            </div>
        </div>
        <?php
    }
}

new AgroepecasApp();
?>