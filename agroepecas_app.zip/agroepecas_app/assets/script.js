jQuery(document).ready(function($) {
    let allData = [];
    let currentTable = "";
    let isLoading = false;
    
    // Ordem específica dos filtros cascata
    const filterOrder = ['marca', 'tipo', 'linha', 'modelo', 'motor', 'modelo_motor'];
    
    // Initialize app
    const appElement = $(".agroepecas-app");
    currentTable = appElement.data("table");
    
    if (currentTable) {
        loadData();
    }
    
    // Event listeners
    $("#agroepecas-btn-filtrar").on("click", applyFilters);
    $("#agroepecas-btn-limpar").on("click", clearFilters);
    
    // Event listeners para filtros cascata específicos
    filterOrder.forEach(function(filter, index) {
        $("#agroepecas-" + filter).on("change", function() {
            updateCascadeFilters(index);
        });
    });
    
    function loadData() {
        if (isLoading) return;
        
        isLoading = true;
        showLoading(true);
        
        $.ajax({
            url: agroepecas_ajax.ajax_url,
            type: "POST",
            data: {
                action: "agroepecas_get_data",
                nonce: agroepecas_ajax.nonce,
                table: currentTable
            },
            success: function(response) {
                if (response.success) {
                    allData = response.data.data;
                    populateInitialFilters();
                    console.log(`✅ Dados carregados: ${allData.length} registros`);
                } else {
                    console.error("❌ Erro ao carregar dados:", response.data);
                    showError("Erro ao carregar dados: " + response.data);
                }
            },
            error: function(xhr, status, error) {
                console.error("❌ Erro AJAX:", error);
                showError("Erro ao conectar com o servidor. Verifique sua conexão.");
            },
            complete: function() {
                isLoading = false;
                showLoading(false);
            }
        });
    }
    
    function populateInitialFilters() {
        // Popular apenas o primeiro filtro (marca) inicialmente
        const marcas = new Set();
        
        allData.forEach(function(item) {
            if (item.marca && item.marca !== "" && item.marca !== null) {
                marcas.add(item.marca);
            }
        });
        
        const marcaSelect = $("#agroepecas-marca");
        marcaSelect.find("option:not(:first)").remove();
        
        Array.from(marcas).sort().forEach(function(marca) {
            marcaSelect.append($("<option>", {
                value: marca,
                text: marca
            }));
        });
    }
    
    function updateCascadeFilters(changedIndex) {
        // Limpar filtros subsequentes
        for (let i = changedIndex + 1; i < filterOrder.length; i++) {
            const select = $("#agroepecas-" + filterOrder[i]);
            select.find("option:not(:first)").remove();
        }
        
        // Atualizar próximo filtro baseado na seleção atual
        updateNextFilter(changedIndex);
    }
    
    function updateNextFilter(currentIndex) {
        if (currentIndex >= filterOrder.length - 1) return;
        
        const nextIndex = currentIndex + 1;
        const nextFilter = filterOrder[nextIndex];
        const nextSelect = $("#agroepecas-" + nextFilter);
        
        if (!nextSelect.length) return;
        
        // Obter valores selecionados até agora
        const selectedValues = {};
        for (let i = 0; i <= currentIndex; i++) {
            const select = $("#agroepecas-" + filterOrder[i]);
            if (select.val()) {
                selectedValues[filterOrder[i]] = select.val();
            }
        }
        
        // Filtrar dados baseado nas seleções atuais
        let filteredData = allData.slice();
        
        Object.keys(selectedValues).forEach(function(key) {
            if (selectedValues[key]) {
                filteredData = filteredData.filter(function(item) {
                    return item[key] && item[key].toString() === selectedValues[key];
                });
            }
        });
        
        // Obter opções únicas para o próximo filtro
        const uniqueValues = new Set();
        filteredData.forEach(function(item) {
            if (item[nextFilter] && item[nextFilter] !== "" && item[nextFilter] !== null) {
                uniqueValues.add(item[nextFilter]);
            }
        });
        
        // Atualizar o select
        nextSelect.find("option:not(:first)").remove();
        
        Array.from(uniqueValues).sort().forEach(function(value) {
            nextSelect.append($("<option>", {
                value: value,
                text: value
            }));
        });
    }
    
    function applyFilters() {
        if (isLoading) return;
        
        isLoading = true;
        showLoading(true);
        hideMessages();
        
        const filters = {};
        
        filterOrder.forEach(function(filter) {
            const value = $("#agroepecas-" + filter).val();
            if (value) {
                filters[filter] = value;
            }
        });
        
        // Verificar se pelo menos um filtro foi selecionado
        const hasFilters = Object.keys(filters).length > 0;
        
        if (!hasFilters) {
            showMessage("Por favor, selecione pelo menos um filtro.", "warning");
            isLoading = false;
            showLoading(false);
            return;
        }
        
        $.ajax({
            url: agroepecas_ajax.ajax_url,
            type: "POST",
            data: {
                action: "agroepecas_filter_data",
                nonce: agroepecas_ajax.nonce,
                table: currentTable,
                filters: filters
            },
            success: function(response) {
                if (response.success) {
                    updateTable(response.data);
                    console.log(`🔍 Filtros aplicados: ${response.data.length} resultados`);
                } else {
                    console.error("❌ Erro ao filtrar dados:", response.data);
                    showError("Erro ao filtrar dados: " + response.data);
                }
            },
            error: function(xhr, status, error) {
                console.error("❌ Erro AJAX:", error);
                showError("Erro ao conectar com o servidor. Tente novamente.");
            },
            complete: function() {
                isLoading = false;
                showLoading(false);
            }
        });
    }
    
    function clearFilters() {
        // Reset all select values
        filterOrder.forEach(function(filter) {
            $("#agroepecas-" + filter).val("");
        });
        
        // Clear table
        $("#agroepecas-result-table").empty();
        
        // Show initial message
        showMessage("Selecione os filtros desejados e clique em 'Filtrar' para ver os resultados.", "info");
        
        // Reset result count
        $("#agroepecas-result-count").text("0");
        
        // Repopular apenas o primeiro filtro
        populateInitialFilters();
        
        // Limpar filtros subsequentes
        for (let i = 1; i < filterOrder.length; i++) {
            const select = $("#agroepecas-" + filterOrder[i]);
            select.find("option:not(:first)").remove();
        }
        
        console.log("🧹 Filtros limpos");
    }
    
    function updateTable(filteredData) {
        const tableBody = $("#agroepecas-result-table");
        const resultCount = $("#agroepecas-result-count");
        
        tableBody.empty();
        resultCount.text(filteredData.length);
        
        hideMessages();
        
        if (filteredData.length === 0) {
            showMessage("Nenhum resultado encontrado para os filtros selecionados. Tente ajustar os critérios de busca.", "warning");
        } else {
            // Debug: Log primeiro item para ver estrutura dos dados
            console.log("Estrutura dos dados:", filteredData[0]);
            
            filteredData.forEach(function(item, index) {
                const row = $("<tr>");
                
                // Usar os nomes EXATOS das colunas conforme mostrado na imagem
                // Ordem: PN, Aplicação, Nota, QTD, OBS
                row.append($("<td>").text(item.pn || ""));
                row.append($("<td>").text(item.aplicacao || ""));
                row.append($("<td>").text(item.nota || ""));
                row.append($("<td>").text(item.qtd || ""));
                row.append($("<td>").text(item.obs || ""));
                
                // Add subtle animation delay for each row
                row.css({
                    opacity: 0,
                    transform: 'translateY(10px)'
                }).delay(index * 50).animate({
                    opacity: 1
                }, 300).css('transform', 'translateY(0)');
                
                tableBody.append(row);
            });
        }
    }
    
    function showLoading(show) {
        if (show) {
            $("#agroepecas-loading").show();
            $("#agroepecas-btn-filtrar").prop("disabled", true).text("Carregando...");
        } else {
            $("#agroepecas-loading").hide();
            $("#agroepecas-btn-filtrar").prop("disabled", false).html('<span class="agroepecas-btn-icon">🔍</span> Filtrar');
        }
    }
    
    function hideMessages() {
        $("#agroepecas-initial-message").hide();
        $("#agroepecas-no-results").hide();
    }
    
    function showMessage(message, type = "info") {
        hideMessages();
        
        if (type === "warning") {
            $("#agroepecas-no-results").show().find("p").text(message);
        } else {
            $("#agroepecas-initial-message").show().find("p").text(message);
        }
    }
    
    function showError(message) {
        console.error("❌ " + message);
        alert("Erro: " + message);
    }
    
    // Add keyboard shortcuts
    $(document).on("keydown", function(e) {
        // Ctrl/Cmd + Enter to apply filters
        if ((e.ctrlKey || e.metaKey) && e.keyCode === 13) {
            e.preventDefault();
            applyFilters();
        }
        
        // Escape to clear filters
        if (e.keyCode === 27) {
            clearFilters();
        }
    });
    
    // Add tooltips for better UX
    $(".agroepecas-btn-primary").attr("title", "Aplicar filtros selecionados (Ctrl+Enter)");
    $(".agroepecas-btn-secondary").attr("title", "Limpar todos os filtros (Esc)");
});