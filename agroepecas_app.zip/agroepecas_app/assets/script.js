jQuery(document).ready(function($) {
    let allData = [];
    let tableColumns = [];
    let currentTable = "";
    let isLoading = false;
    
    // Initialize app
    const appElement = $(".agroepecas-app");
    currentTable = appElement.data("table");
    
    if (currentTable) {
        loadData();
    }
    
    // Event listeners
    $("#agroepecas-btn-filtrar").on("click", applyFilters);
    $("#agroepecas-btn-limpar").on("click", clearFilters);
    
    function loadData() {
        if (isLoading) return;
        
        isLoading = true;
        showLoading(true);
        
        $.ajax({
            url: agroepecas_ajax.ajax_url,
            type: "POST",
            data: {
                action: "agroepecas_get_data",
                nonce: agroepecas_ajax.nonce,
                table: currentTable
            },
            success: function(response) {
                if (response.success) {
                    tableColumns = response.data.columns;
                    allData = response.data.data;
                    
                    createFilters();
                    createTableHeaders();
                    populateFilters();
                    
                    console.log(`✅ Dados carregados: ${allData.length} registros`);
                } else {
                    console.error("❌ Erro ao carregar dados:", response.data);
                    showError("Erro ao carregar dados: " + response.data);
                }
            },
            error: function(xhr, status, error) {
                console.error("❌ Erro AJAX:", error);
                showError("Erro ao conectar com o servidor. Verifique sua conexão.");
            },
            complete: function() {
                isLoading = false;
                showLoading(false);
            }
        });
    }
    
    function createFilters() {
        const filtersContainer = $("#agroepecas-filters-container");
        filtersContainer.empty();
        
        // Skip ID column and create filters for other columns
        const filterColumns = tableColumns.filter(col => 
            col.Field.toLowerCase() !== "id" && 
            col.Field.toLowerCase() !== "created_at" &&
            col.Field.toLowerCase() !== "updated_at"
        );
        
        filterColumns.forEach(function(column) {
            const fieldName = column.Field;
            const fieldLabel = formatFieldLabel(fieldName);
            
            const filterGroup = $(`
                <div class="agroepecas-filter-group">
                    <label class="agroepecas-filter-label" for="agroepecas-${fieldName}">
                        ${fieldLabel}
                    </label>
                    <select id="agroepecas-${fieldName}" 
                            class="agroepecas-select" 
                            data-column="${fieldName}"
                            aria-label="Filtro para ${fieldLabel}">
                        <option value="">Todos</option>
                    </select>
                </div>
            `);
            
            filtersContainer.append(filterGroup);
        });
        
        // Add change event listeners for cascading filters
        $(".agroepecas-select").on("change", function() {
            updateDependentFilters($(this).data("column"));
        });
    }
    
    function formatFieldLabel(fieldName) {
        return fieldName
            .split('_')
            .map(word => word.charAt(0).toUpperCase() + word.slice(1))
            .join(' ');
    }
    
    function createTableHeaders() {
        const tableHead = $("#agroepecas-table-head");
        tableHead.empty();
        
        const headerRow = $("<tr>");
        
        tableColumns.forEach(function(column) {
            if (column.Field.toLowerCase() !== "id" && 
                column.Field.toLowerCase() !== "created_at" &&
                column.Field.toLowerCase() !== "updated_at") {
                const fieldLabel = formatFieldLabel(column.Field);
                headerRow.append(`<th>${fieldLabel}</th>`);
            }
        });
        
        tableHead.append(headerRow);
    }
    
    function populateFilters() {
        const filters = {};
        
        // Initialize filter sets
        $(".agroepecas-select").each(function() {
            const column = $(this).data("column");
            if (column) {
                filters[column] = new Set();
            }
        });
        
        // Populate filter options from data
        allData.forEach(function(item) {
            Object.keys(filters).forEach(function(column) {
                if (item[column] && item[column] !== "" && item[column] !== null) {
                    filters[column].add(item[column]);
                }
            });
        });
        
        // Update select options
        Object.keys(filters).forEach(function(column) {
            const select = $("#agroepecas-" + column);
            const sortedValues = Array.from(filters[column]).sort((a, b) => {
                // Try to sort numerically if possible, otherwise alphabetically
                const numA = parseFloat(a);
                const numB = parseFloat(b);
                if (!isNaN(numA) && !isNaN(numB)) {
                    return numA - numB;
                }
                return a.toString().localeCompare(b.toString());
            });
            
            select.find("option:not(:first)").remove();
            
            sortedValues.forEach(function(value) {
                select.append($("<option>", {
                    value: value,
                    text: value
                }));
            });
        });
    }
    
    function updateDependentFilters(changedColumn) {
        const currentFilters = {};
        
        // Get current filter values
        $(".agroepecas-select").each(function() {
            const column = $(this).data("column");
            if (column) {
                currentFilters[column] = $(this).val();
            }
        });
        
        // Filter data based on current selections
        let filteredData = allData.slice();
        
        Object.keys(currentFilters).forEach(function(key) {
            if (currentFilters[key] && currentFilters[key] !== "") {
                filteredData = filteredData.filter(function(item) {
                    return item[key] && item[key].toString() === currentFilters[key];
                });
            }
        });
        
        // Update dependent filters
        Object.keys(currentFilters).forEach(function(column) {
            if (column === changedColumn) return; // Skip the changed column
            
            const select = $("#agroepecas-" + column);
            const currentValue = select.val();
            
            // Don't update if this select is currently focused
            if (select.is(":focus")) return;
            
            // Clear existing options except "Todos"
            select.find("option:not(:first)").remove();
            
            // Get unique values for this column from filtered data
            const uniqueValues = new Set();
            filteredData.forEach(function(item) {
                if (item[column] && item[column] !== "" && item[column] !== null) {
                    uniqueValues.add(item[column]);
                }
            });
            
            // Sort and add options
            const sortedValues = Array.from(uniqueValues).sort((a, b) => {
                const numA = parseFloat(a);
                const numB = parseFloat(b);
                if (!isNaN(numA) && !isNaN(numB)) {
                    return numA - numB;
                }
                return a.toString().localeCompare(b.toString());
            });
            
            sortedValues.forEach(function(value) {
                select.append($("<option>", {
                    value: value,
                    text: value
                }));
            });
            
            // Restore previous value if it still exists
            if (currentValue && sortedValues.includes(currentValue)) {
                select.val(currentValue);
            } else if (currentValue && !sortedValues.includes(currentValue)) {
                select.val(""); // Clear if previous value no longer available
            }
        });
    }
    
    function applyFilters() {
        if (isLoading) return;
        
        isLoading = true;
        showLoading(true);
        hideMessages();
        
        const filters = {};
        
        $(".agroepecas-select").each(function() {
            const column = $(this).data("column");
            if (column) {
                filters[column] = $(this).val();
            }
        });
        
        // Check if any filters are selected
        const hasFilters = Object.values(filters).some(value => value !== "");
        
        if (!hasFilters) {
            showMessage("Por favor, selecione pelo menos um filtro.", "warning");
            isLoading = false;
            showLoading(false);
            return;
        }
        
        $.ajax({
            url: agroepecas_ajax.ajax_url,
            type: "POST",
            data: {
                action: "agroepecas_filter_data",
                nonce: agroepecas_ajax.nonce,
                table: currentTable,
                filters: filters
            },
            success: function(response) {
                if (response.success) {
                    updateTable(response.data);
                    console.log(`🔍 Filtros aplicados: ${response.data.length} resultados`);
                } else {
                    console.error("❌ Erro ao filtrar dados:", response.data);
                    showError("Erro ao filtrar dados: " + response.data);
                }
            },
            error: function(xhr, status, error) {
                console.error("❌ Erro AJAX:", error);
                showError("Erro ao conectar com o servidor. Tente novamente.");
            },
            complete: function() {
                isLoading = false;
                showLoading(false);
            }
        });
    }
    
    function clearFilters() {
        // Reset all select values
        $(".agroepecas-select").val("");
        
        // Clear table
        $("#agroepecas-result-table").empty();
        
        // Show initial message
        showMessage("Selecione os filtros desejados e clique em 'Filtrar' para ver os resultados.", "info");
        
        // Reset result count
        $("#agroepecas-result-count").text("0");
        
        // Repopulate all filters with original data
        populateFilters();
        
        console.log("🧹 Filtros limpos");
    }
    
    function updateTable(filteredData) {
        const tableBody = $("#agroepecas-result-table");
        const resultCount = $("#agroepecas-result-count");
        
        tableBody.empty();
        resultCount.text(filteredData.length);
        
        hideMessages();
        
        if (filteredData.length === 0) {
            showMessage("Nenhum resultado encontrado para os filtros selecionados. Tente ajustar os critérios de busca.", "warning");
        } else {
            filteredData.forEach(function(item, index) {
                const row = $("<tr>");
                
                tableColumns.forEach(function(column) {
                    if (column.Field.toLowerCase() !== "id" && 
                        column.Field.toLowerCase() !== "created_at" &&
                        column.Field.toLowerCase() !== "updated_at") {
                        const cellValue = item[column.Field] || "";
                        const cell = $("<td>").text(cellValue);
                        row.append(cell);
                    }
                });
                
                // Add subtle animation delay for each row
                row.css({
                    opacity: 0,
                    transform: 'translateY(10px)'
                }).delay(index * 50).animate({
                    opacity: 1
                }, 300).css('transform', 'translateY(0)');
                
                tableBody.append(row);
            });
        }
    }
    
    function showLoading(show) {
        if (show) {
            $("#agroepecas-loading").show();
            $("#agroepecas-btn-filtrar").prop("disabled", true).text("Carregando...");
        } else {
            $("#agroepecas-loading").hide();
            $("#agroepecas-btn-filtrar").prop("disabled", false).html('<span class="agroepecas-btn-icon">🔍</span> Filtrar');
        }
    }
    
    function hideMessages() {
        $("#agroepecas-initial-message").hide();
        $("#agroepecas-no-results").hide();
    }
    
    function showMessage(message, type = "info") {
        hideMessages();
        
        if (type === "warning") {
            $("#agroepecas-no-results").show().find("p").text(message);
        } else {
            $("#agroepecas-initial-message").show().find("p").text(message);
        }
    }
    
    function showError(message) {
        console.error("❌ " + message);
        alert("Erro: " + message);
    }
    
    // Add keyboard shortcuts
    $(document).on("keydown", function(e) {
        // Ctrl/Cmd + Enter to apply filters
        if ((e.ctrlKey || e.metaKey) && e.keyCode === 13) {
            e.preventDefault();
            applyFilters();
        }
        
        // Escape to clear filters
        if (e.keyCode === 27) {
            clearFilters();
        }
    });
    
    // Add tooltips for better UX
    $(".agroepecas-btn-primary").attr("title", "Aplicar filtros selecionados (Ctrl+Enter)");
    $(".agroepecas-btn-secondary").attr("title", "Limpar todos os filtros (Esc)");
});