# AGRO&PEÇAS App Plugin

Sistema de aplicações para filtros e conversores com sincronização automática para WordPress.

## Descrição

Este plugin permite criar aplicações de filtros e conversores que podem ser sincronizadas automaticamente com planilhas do Google Sheets.

## Características

- ✅ Sistema de filtros para máquinas agrícolas
- ✅ Conversor de medidas CARRARO
- ✅ Sincronização automática com Google Sheets
- ✅ Interface responsiva e moderna
- ✅ Painel administrativo completo
- ✅ Shortcodes fáceis de usar

## Instalação

1. Faça upload do arquivo ZIP via **Plugins > Adicionar novo > Enviar plugin**
2. Ative o plugin
3. Configure as URLs das planilhas Google Sheets no painel administrativo

## Shortcodes Disponíveis

### Sistema de Filtros
```
[agroepecas_filtros planilha="URL_GOOGLE_SHEETS" aba="NOME_ABA"]
```

### Sistema de Conversão
```
[agroepecas_conversor planilha="URL_GOOGLE_SHEETS" aba="NOME_ABA"]
```

## Configuração

1. Acesse **AGRO&PEÇAS Apps** no menu administrativo
2. Configure as URLs das suas planilhas Google Sheets
3. Execute a sincronização manual se necessário
4. Use os shortcodes em suas páginas/posts

## Requisitos

- WordPress 5.0+
- PHP 7.4+
- Acesso à internet para sincronização

## Suporte

Para suporte técnico, entre em contato com a equipe AGRO&PEÇAS.

## Versão

**2.0** - Sistema completo com sincronização automática