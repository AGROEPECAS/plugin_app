<?php
/**
 * Plugin Name: AGRO&PEÇAS App
 * Description: Sistema de aplicações para filtros e conversores com sincronização automática
 * Version: 2.0
 * Author: AGRO&PEÇAS
 * Text Domain: agroepecas-app
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class AgroepecasApp {
    
    public function __construct() {
        register_activation_hook(__FILE__, [$this, 'activate']);
        register_deactivation_hook(__FILE__, [$this, 'deactivate']);
        
        add_action('init', [$this, 'init']);
        add_action('admin_init', [$this, 'verify_tables']);
        add_action('agroepecas_sync_cron', [$this, 'sync_tables']);
        
        // Handle manual sync
        add_action('admin_post_agroepecas_manual_sync', [$this, 'handle_manual_sync']);
    }
    
    public function activate() {
        $this->create_tables();
        $this->setup_cron();
        
        // Add activation notice
        add_option('agroepecas_activation_notice', true);
    }
    
    public function deactivate() {
        wp_clear_scheduled_hook('agroepecas_sync_cron');
    }
    
    private function create_tables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        $tables = [
            'app_filtros' => "
                CREATE TABLE {$wpdb->prefix}app_filtros (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    marca VARCHAR(255),
                    linha VARCHAR(255),
                    motor VARCHAR(255),
                    tipo VARCHAR(255),
                    modelo VARCHAR(255),
                    modelo_motor VARCHAR(255),
                    aplicacao TEXT,
                    nota VARCHAR(500),
                    qtd VARCHAR(100),
                    obs TEXT
                ) {$charset_collate}
            ",
            'app_conversoes' => "
                CREATE TABLE {$wpdb->prefix}app_conversoes (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    sistema_origem VARCHAR(255),
                    sistema_destino VARCHAR(255),
                    valor_origem DECIMAL(10,2),
                    valor_destino DECIMAL(10,2)
                ) {$charset_collate}
            "
        ];
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        
        foreach ($tables as $table_name => $sql) {
            if ($wpdb->get_var("SHOW TABLES LIKE '{$wpdb->prefix}{$table_name}'") != $wpdb->prefix.$table_name) {
                dbDelta($sql);
            }
        }
    }
    
    private function setup_cron() {
        if (!wp_next_scheduled('agroepecas_sync_cron')) {
            wp_schedule_event(time(), 'twicedaily', 'agroepecas_sync_cron');
        }
    }
    
    public function sync_tables() {
        $sync_sources = [
            'filtros' => [
                'planilha' => 'https://docs.google.com/spreadsheets/d/SUA_PLANILHA_FILTROS/edit',
                'aba' => 'Dados'
            ],
            'conversoes' => [
                'planilha' => 'https://docs.google.com/spreadsheets/d/SUA_PLANILHA_CONVERSOES/edit',
                'aba' => 'Tabela'
            ]
        ];
        
        foreach ($sync_sources as $tipo => $source) {
            $this->sync_google_sheet(
                $source['planilha'],
                $source['aba'],
                "app_{$tipo}"
            );
        }
    }
    
    private function sync_google_sheet($planilha_url, $aba, $tabela) {
        global $wpdb;
        
        if (!preg_match('/\/d\/([a-zA-Z0-9-_]+)/', $planilha_url, $matches)) {
            error_log("AGRO&PEÇAS: URL da planilha inválida - {$planilha_url}");
            return false;
        }
        
        $planilha_id = $matches[1];
        $url = "https://docs.google.com/spreadsheets/d/{$planilha_id}/gviz/tq?tqx=out:json&sheet=" . urlencode($aba);
        
        $response = wp_remote_get($url, [
            'timeout' => 45,
            'sslverify' => false
        ]);
        
        if (is_wp_error($response)) {
            error_log("AGRO&PEÇAS: Erro ao acessar planilha - " . $response->get_error_message());
            return false;
        }
        
        $body = wp_remote_retrieve_body($response);
        $json = substr($body, strpos($body, '{'), strrpos($body, '}') - strpos($body, '{') + 1);
        $data = json_decode($json, true);
        
        if (!$data || !isset($data['table']['rows'])) {
            error_log("AGRO&PEÇAS: Formato de dados inválido");
            return false;
        }
        
        $wpdb->query("TRUNCATE TABLE {$wpdb->prefix}{$tabela}");
        
        foreach ($data['table']['rows'] as $row) {
            if (empty($row['c'])) continue;
            
            $cols = $row['c'];
            $insert_data = [];
            
            switch ($tabela) {
                case 'app_filtros':
                    $insert_data = [
                        'marca' => isset($cols[0]['v']) ? $cols[0]['v'] : '',
                        'linha' => isset($cols[1]['v']) ? $cols[1]['v'] : '',
                        'motor' => isset($cols[2]['v']) ? $cols[2]['v'] : '',
                        'tipo' => isset($cols[3]['v']) ? $cols[3]['v'] : '',
                        'modelo' => isset($cols[4]['v']) ? $cols[4]['v'] : '',
                        'modelo_motor' => isset($cols[5]['v']) ? $cols[5]['v'] : '',
                        'aplicacao' => isset($cols[6]['v']) ? $cols[6]['v'] : '',
                        'nota' => isset($cols[7]['v']) ? $cols[7]['v'] : '',
                        'qtd' => isset($cols[8]['v']) ? $cols[8]['v'] : '',
                        'obs' => isset($cols[9]['v']) ? $cols[9]['v'] : ''
                    ];
                    break;
                    
                case 'app_conversoes':
                    $insert_data = [
                        'sistema_origem' => isset($cols[0]['v']) ? $cols[0]['v'] : '',
                        'sistema_destino' => isset($cols[1]['v']) ? $cols[1]['v'] : '',
                        'valor_origem' => isset($cols[2]['v']) ? $cols[2]['v'] : 0,
                        'valor_destino' => isset($cols[3]['v']) ? $cols[3]['v'] : 0
                    ];
                    break;
            }
            
            if (!empty($insert_data)) {
                $wpdb->insert("{$wpdb->prefix}{$tabela}", $insert_data);
            }
        }
        
        return true;
    }
    
    public function verify_tables() {
        global $wpdb;
        
        // Show activation notice
        if (get_option('agroepecas_activation_notice')) {
            add_action('admin_notices', function() {
                echo '<div class="notice notice-success is-dismissible">';
                echo '<p><strong>AGRO&PEÇAS App</strong> foi ativado com sucesso!</p>';
                echo '</div>';
            });
            delete_option('agroepecas_activation_notice');
        }
        
        $tables = [
            'app_filtros' => __('Tabela de Filtros', 'agroepecas-app'),
            'app_conversoes' => __('Tabela de Conversões', 'agroepecas-app')
        ];
        
        foreach ($tables as $table => $name) {
            $table_name = $wpdb->prefix . $table;
            if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
                add_action('admin_notices', function() use ($name) {
                    echo '<div class="notice notice-error"><p>';
                    printf(
                        __('%s não encontrada. O plugin AGRO&PEÇAS não funcionará corretamente.', 'agroepecas-app'),
                        '<strong>' . $name . '</strong>'
                    );
                    echo '</p></div>';
                });
            }
        }
    }
    
    public function init() {
        add_shortcode('agroepecas_filtros', [$this, 'display_filtros']);
        add_shortcode('agroepecas_conversor', [$this, 'display_conversor']);
        
        // AJAX handlers
        add_action('wp_ajax_agroepecas_get_data', [$this, 'ajax_get_data']);
        add_action('wp_ajax_agroepecas_filter_data', [$this, 'ajax_filter_data']);
        add_action('wp_ajax_nopriv_agroepecas_get_data', [$this, 'ajax_get_data']);
        add_action('wp_ajax_nopriv_agroepecas_filter_data', [$this, 'ajax_filter_data']);
        
        // Enqueue assets
        add_action('wp_enqueue_scripts', [$this, 'enqueue_scripts']);
        
        // Admin menu
        add_action('admin_menu', [$this, 'add_admin_menu']);
    }
    
    public function enqueue_scripts() {
        global $post;
        
        if (!is_a($post, 'WP_Post')) return;
        
        $has_shortcode = has_shortcode($post->post_content, 'agroepecas_filtros') || 
                         has_shortcode($post->post_content, 'agroepecas_conversor');
        
        if ($has_shortcode) {
            // Enqueue CSS
            $css_file = plugin_dir_path(__FILE__) . 'assets/style.css';
            if (file_exists($css_file)) {
                wp_enqueue_style(
                    'agroepecas-style',
                    plugins_url('assets/style.css', __FILE__),
                    [],
                    filemtime($css_file)
                );
            } else {
                // Inline CSS if file doesn't exist
                wp_add_inline_style('wp-admin', $this->get_default_css());
            }
            
            // Enqueue JavaScript
            $js_file = plugin_dir_path(__FILE__) . 'assets/script.js';
            if (file_exists($js_file)) {
                wp_enqueue_script(
                    'agroepecas-script',
                    plugins_url('assets/script.js', __FILE__),
                    ['jquery'],
                    filemtime($js_file),
                    true
                );
            } else {
                // Inline JS if file doesn't exist
                wp_add_inline_script('jquery', $this->get_default_js());
            }
            
            wp_localize_script('agroepecas-script', 'agroepecas_ajax', [
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('agroepecas_nonce')
            ]);
        }
    }
    
    private function get_default_css() {
        return '
            .agroepecas-app { max-width: 1200px; margin: 0 auto; }
            .agroepecas-header { background: #2c5aa0; color: white; padding: 20px 0; }
            .agroepecas-container { max-width: 1200px; margin: 0 auto; padding: 0 20px; }
            .agroepecas-logo { height: 50px; margin-right: 20px; }
            .agroepecas-main { padding: 40px 0; }
            .agroepecas-filters-section, .agroepecas-results-section { margin-bottom: 40px; }
            .agroepecas-btn-primary { background: #2c5aa0; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; }
            .agroepecas-btn-secondary { background: #6c757d; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; margin-left: 10px; }
            .agroepecas-table { width: 100%; border-collapse: collapse; }
            .agroepecas-table th, .agroepecas-table td { padding: 12px; border: 1px solid #ddd; text-align: left; }
            .agroepecas-table th { background: #f8f9fa; font-weight: bold; }
            .agroepecas-spinner { border: 4px solid #f3f3f3; border-top: 4px solid #3498db; border-radius: 50%; width: 40px; height: 40px; animation: spin 2s linear infinite; margin: 0 auto; }
            @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
        ';
    }
    
    private function get_default_js() {
        return '
            jQuery(document).ready(function($) {
                // Basic functionality will be added here
                console.log("AGRO&PEÇAS App loaded");
            });
        ';
    }
    
    public function display_filtros($atts) {
        $a = shortcode_atts([
            'planilha' => '',
            'aba' => 'Dados'
        ], $atts);
        
        return $this->render_app(
            'Aplicação de Filtros Para Máquinas Agrícolas',
            'app_filtros',
            'filtros',
            $a['planilha'],
            $a['aba']
        );
    }
    
    public function display_conversor($atts) {
        $a = shortcode_atts([
            'planilha' => '',
            'aba' => 'Tabela'
        ], $atts);
        
        return $this->render_app(
            'Conversor de Medidas CARRARO',
            'app_conversoes',
            'conversor',
            $a['planilha'],
            $a['aba']
        );
    }
    
    private function render_app($titulo, $tabela, $tipo, $planilha = '', $aba = '') {
        ob_start();
        ?>
        <div class="agroepecas-app" 
             data-table="<?php echo esc_attr($tabela); ?>" 
             data-tipo="<?php echo esc_attr($tipo); ?>"
             data-planilha="<?php echo esc_attr($planilha); ?>"
             data-aba="<?php echo esc_attr($aba); ?>">
            
            <header class="agroepecas-header">
                <div class="agroepecas-container">
                    <img src="https://i.imgur.com/xqCuadH.png" alt="AGRO&PEÇAS" class="agroepecas-logo">
                    <h1><?php echo esc_html($titulo); ?></h1>
                </div>
            </header>

            <main class="agroepecas-main">
                <div class="agroepecas-container">
                    <div class="agroepecas-filters-section">
                        <h2><?php echo $tipo === 'conversor' ? 'Dados para Conversão' : 'Filtros'; ?></h2>
                        <div id="agroepecas-filters-container"></div>
                        <div class="agroepecas-buttons">
                            <button id="agroepecas-btn-filtrar" class="agroepecas-btn-primary">
                                <?php echo $tipo === 'conversor' ? 'Converter' : 'Filtrar'; ?>
                            </button>
                            <button id="agroepecas-btn-limpar" class="agroepecas-btn-secondary">Limpar</button>
                            <?php if (!empty($planilha)): ?>
                                <button id="agroepecas-btn-sync" class="agroepecas-btn-secondary" 
                                        data-planilha="<?php echo esc_attr($planilha); ?>"
                                        data-aba="<?php echo esc_attr($aba); ?>"
                                        data-tabela="<?php echo esc_attr($tabela); ?>">
                                    Sincronizar
                                </button>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="agroepecas-results-section">
                        <h2>Resultados</h2>
                        <div id="agroepecas-loading" style="display: none;">
                            <div class="agroepecas-spinner"></div>
                            <p>Carregando dados...</p>
                        </div>
                        <div id="agroepecas-results-container">
                            <div class="agroepecas-table-container">
                                <table class="agroepecas-table">
                                    <thead id="agroepecas-table-head"></thead>
                                    <tbody id="agroepecas-result-table"></tbody>
                                </table>
                            </div>
                            <div id="agroepecas-initial-message">
                                <?php echo $tipo === 'conversor' 
                                    ? 'Preencha os campos e clique em "Converter"' 
                                    : 'Selecione os filtros e clique em "Filtrar"'; ?>
                            </div>
                            <div id="agroepecas-no-results" style="display: none;">
                                Nenhum resultado encontrado
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
        <?php
        return ob_get_clean();
    }
    
    public function ajax_get_data() {
        check_ajax_referer('agroepecas_nonce', 'nonce');
        
        $table = sanitize_text_field($_POST['table']);
        $allowed_tables = ['app_filtros', 'app_conversoes'];
        
        if (!in_array($table, $allowed_tables)) {
            wp_send_json_error(__('Tabela não permitida', 'agroepecas-app'), 400);
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . $table;
        
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
            wp_send_json_error(__('Tabela não encontrada', 'agroepecas-app'), 404);
        }
        
        $columns = $wpdb->get_results("DESCRIBE $table_name", ARRAY_A);
        $results = $wpdb->get_results("SELECT * FROM $table_name ORDER BY id LIMIT 500", ARRAY_A);
        
        wp_send_json_success([
            'columns' => $columns,
            'data' => $results
        ]);
    }
    
    public function ajax_filter_data() {
        check_ajax_referer('agroepecas_nonce', 'nonce');
        
        $table = sanitize_text_field($_POST['table']);
        $allowed_tables = ['app_filtros', 'app_conversoes'];
        
        if (!in_array($table, $allowed_tables)) {
            wp_send_json_error(__('Tabela não permitida', 'agroepecas-app'), 400);
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . $table;
        
        $filters = array_map('sanitize_text_field', $_POST['filters']);
        
        $where = [];
        $params = [];
        
        foreach ($filters as $key => $value) {
            if (!empty($value)) {
                $where[] = "`$key` LIKE %s";
                $params[] = '%' . $value . '%';
            }
        }
        
        $sql = "SELECT * FROM $table_name";
        if (!empty($where)) {
            $sql .= " WHERE " . implode(' AND ', $where);
        }
        $sql .= " ORDER BY id LIMIT 500";
        
        $results = $params 
            ? $wpdb->get_results($wpdb->prepare($sql, $params), ARRAY_A)
            : $wpdb->get_results($sql, ARRAY_A);
        
        wp_send_json_success($results);
    }
    
    public function handle_manual_sync() {
        if (!current_user_can('manage_options')) {
            wp_die(__('Acesso negado', 'agroepecas-app'));
        }
        
        check_admin_referer('agroepecas_sync_nonce');
        
        $this->sync_tables();
        
        wp_redirect(add_query_arg([
            'page' => 'agroepecas-app',
            'sync' => 'success'
        ], admin_url('admin.php')));
        exit;
    }
    
    public function add_admin_menu() {
        add_menu_page(
            'AGRO&PEÇAS Apps',
            'AGRO&PEÇAS Apps',
            'manage_options',
            'agroepecas-app',
            [$this, 'admin_page'],
            'dashicons-admin-tools',
            30
        );
    }
    
    public function admin_page() {
        global $wpdb;
        
        // Show sync success message
        if (isset($_GET['sync']) && $_GET['sync'] === 'success') {
            echo '<div class="notice notice-success"><p>Sincronização executada com sucesso!</p></div>';
        }
        ?>
        <div class="wrap">
            <h1>AGRO&PEÇAS - Sistema de Aplicações</h1>
            
            <div class="card">
                <h2>🔧 Shortcodes Disponíveis</h2>
                <ul>
                    <li>
                        <strong>Sistema de Filtros:</strong> 
                        <code>[agroepecas_filtros planilha="URL_GOOGLE_SHEETS" aba="NOME_ABA"]</code>
                    </li>
                    <li>
                        <strong>Sistema de Conversão:</strong> 
                        <code>[agroepecas_conversor planilha="URL_GOOGLE_SHEETS" aba="NOME_ABA"]</code>
                    </li>
                </ul>
            </div>
            
            <div class="card">
                <h2>📊 Status das Tabelas</h2>
                <?php
                $tables = [
                    'app_filtros' => [
                        'name' => 'Sistema de Filtros'
                    ],
                    'app_conversoes' => [
                        'name' => 'Sistema de Conversão'
                    ]
                ];
                
                foreach ($tables as $table => $info) {
                    $table_name = $wpdb->prefix . $table;
                    $exists = $wpdb->get_var("SHOW TABLES LIKE '$table_name'") == $table_name;
                    $count = $exists ? $wpdb->get_var("SELECT COUNT(*) FROM $table_name") : 0;
                    
                    echo '<p>';
                    echo $exists ? '✅' : '❌';
                    echo ' <strong>' . esc_html($info['name']) . '</strong> (' . esc_html($table) . '): ';
                    echo $exists ? number_format($count) . ' registros' : 'Tabela não encontrada';
                    echo '</p>';
                }
                ?>
                
                <h3>Sincronização com Google Sheets</h3>
                <form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
                    <input type="hidden" name="action" value="agroepecas_manual_sync">
                    <?php wp_nonce_field('agroepecas_sync_nonce'); ?>
                    <p>
                        <button type="submit" class="button button-primary">
                            Executar Sincronização Agora
                        </button>
                    </p>
                </form>
            </div>
            
            <div class="card">
                <h2>ℹ️ Informações do Plugin</h2>
                <p><strong>Versão:</strong> 2.0</p>
                <p><strong>Status:</strong> Ativo e funcionando</p>
                <p><strong>Última verificação:</strong> <?php echo date('d/m/Y H:i:s'); ?></p>
            </div>
        </div>
        <?php
    }
}

// Initialize the plugin
new AgroepecasApp();
?>