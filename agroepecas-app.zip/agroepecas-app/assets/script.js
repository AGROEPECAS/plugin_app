/**
 * AGRO&PEÇAS App JavaScript
 * Handles filtering, data loading, and UI interactions
 */

jQuery(document).ready(function($) {
    'use strict';
    
    console.log('🚜 AGRO&PEÇAS App iniciado');
    
    // Global variables
    let appData = {
        currentData: [],
        allData: [],
        columns: [],
        isLoading: false,
        appType: '',
        tableName: ''
    };
    
    // Initialize each app instance
    $('.agroepecas-app').each(function() {
        initializeApp($(this));
    });
    
    /**
     * Initialize a single app instance
     */
    function initializeApp($app) {
        const tableAttr = $app.data('table');
        const tipoAttr = $app.data('tipo');
        const planilhaAttr = $app.data('planilha');
        const abaAttr = $app.data('aba');
        
        console.log('🔧 Inicializando app:', { tableAttr, tipoAttr, planilhaAttr, abaAttr });
        
        // Store app context
        $app.data('appContext', {
            table: tableAttr,
            tipo: tipoAttr,
            planilha: planilhaAttr,
            aba: abaAttr
        });
        
        // Load initial data
        loadData($app);
        
        // Bind events for this app instance
        bindEvents($app);
    }
    
    /**
     * Bind events for a specific app instance
     */
    function bindEvents($app) {
        const context = $app.data('appContext');
        
        // Filter button
        $app.find('#agroepecas-btn-filtrar').off('click').on('click', function(e) {
            e.preventDefault();
            handleFilter($app);
        });
        
        // Clear button
        $app.find('#agroepecas-btn-limpar').off('click').on('click', function(e) {
            e.preventDefault();
            handleClear($app);
        });
        
        // Sync button
        $app.find('#agroepecas-btn-sync').off('click').on('click', function(e) {
            e.preventDefault();
            handleSync($app);
        });
        
        // Filter change events
        $app.find('#agroepecas-filters-container').off('change', 'select, input').on('change', 'select, input', function() {
            // Auto-filter on change (optional)
            // handleFilter($app);
        });
        
        // Enter key in filter inputs
        $app.find('#agroepecas-filters-container').off('keypress', 'input').on('keypress', 'input', function(e) {
            if (e.which === 13) { // Enter key
                e.preventDefault();
                handleFilter($app);
            }
        });
    }
    
    /**
     * Load data from database
     */
    function loadData($app) {
        const context = $app.data('appContext');
        
        if (!context || !context.table) {
            console.error('❌ Contexto da aplicação não encontrado');
            showError($app, 'Erro na configuração da aplicação');
            return;
        }
        
        if (appData.isLoading) {
            console.log('⏳ Carregamento já em andamento...');
            return;
        }
        
        appData.isLoading = true;
        showLoading($app);
        
        console.log('📡 Carregando dados da tabela:', context.table);
        
        $.ajax({
            url: agroepecas_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'agroepecas_get_data',
                table: context.table,
                nonce: agroepecas_ajax.nonce
            },
            success: function(response) {
                console.log('✅ Dados carregados:', response);
                
                if (response.success && response.data) {
                    appData.allData = response.data.data || [];
                    appData.columns = response.data.columns || [];
                    appData.currentData = appData.allData;
                    appData.tableName = context.table;
                    appData.appType = context.tipo;
                    
                    $app.data('appData', appData);
                    
                    buildFilters($app);
                    displayResults($app, appData.allData);
                    
                    showMessage($app, `Dados carregados: ${appData.allData.length} registros`, 'success');
                } else {
                    console.error('❌ Erro na resposta:', response);
                    showError($app, response.data || 'Erro ao carregar dados');
                }
            },
            error: function(xhr, status, error) {
                console.error('❌ Erro AJAX:', { xhr, status, error });
                showError($app, 'Erro de comunicação com o servidor');
            },
            complete: function() {
                appData.isLoading = false;
                hideLoading($app);
            }
        });
    }
    
    /**
     * Build filter controls based on data columns
     */
    function buildFilters($app) {
        const context = $app.data('appContext');
        const data = $app.data('appData') || appData;
        const $container = $app.find('#agroepecas-filters-container');
        
        if (!data.columns || data.columns.length === 0) {
            $container.html('<p>Nenhum filtro disponível</p>');
            return;
        }
        
        let filtersHtml = '<div class="agroepecas-filters-grid">';
        
        // Skip 'id' column and build filters for other columns
        data.columns.forEach(function(column) {
            if (column.Field === 'id') return;
            
            const fieldName = column.Field;
            const fieldLabel = formatFieldLabel(fieldName);
            
            // Get unique values for this column
            const uniqueValues = getUniqueValues(data.allData, fieldName);
            
            if (uniqueValues.length > 0) {
                filtersHtml += `
                    <div class="agroepecas-filter-group">
                        <label for="filter-${fieldName}">${fieldLabel}</label>
                        <select id="filter-${fieldName}" name="${fieldName}" data-field="${fieldName}">
                            <option value="">Todos</option>
                `;
                
                uniqueValues.forEach(function(value) {
                    if (value && value.toString().trim()) {
                        const cleanValue = escapeHtml(value.toString().trim());
                        filtersHtml += `<option value="${cleanValue}">${cleanValue}</option>`;
                    }
                });
                
                filtersHtml += `
                        </select>
                    </div>
                `;
            }
        });
        
        filtersHtml += '</div>';
        $container.html(filtersHtml);
        
        console.log('🔍 Filtros construídos para', data.columns.length, 'colunas');
    }
    
    /**
     * Handle filter action
     */
    function handleFilter($app) {
        const context = $app.data('appContext');
        const data = $app.data('appData') || appData;
        
        if (!data.allData || data.allData.length === 0) {
            showError($app, 'Nenhum dado disponível para filtrar');
            return;
        }
        
        showLoading($app);
        
        // Collect filter values
        const filters = {};
        $app.find('#agroepecas-filters-container select, #agroepecas-filters-container input').each(function() {
            const $field = $(this);
            const fieldName = $field.data('field') || $field.attr('name');
            const value = $field.val();
            
            if (fieldName && value && value.trim()) {
                filters[fieldName] = value.trim();
            }
        });
        
        console.log('🔍 Aplicando filtros:', filters);
        
        if (Object.keys(filters).length === 0) {
            // No filters, show all data
            data.currentData = data.allData;
            displayResults($app, data.currentData);
            hideLoading($app);
            showMessage($app, 'Filtros limpos. Mostrando todos os registros.', 'info');
            return;
        }
        
        // Apply filters locally for better performance
        const filteredData = data.allData.filter(function(row) {
            return Object.keys(filters).every(function(field) {
                const rowValue = row[field];
                const filterValue = filters[field];
                
                if (!rowValue) return false;
                
                return rowValue.toString().toLowerCase().includes(filterValue.toLowerCase());
            });
        });
        
        data.currentData = filteredData;
        displayResults($app, filteredData);
        hideLoading($app);
        
        const message = filteredData.length > 0 
            ? `Encontrados ${filteredData.length} resultados`
            : 'Nenhum resultado encontrado para os filtros aplicados';
            
        showMessage($app, message, filteredData.length > 0 ? 'success' : 'error');
        
        console.log('✅ Filtros aplicados:', filteredData.length, 'resultados');
    }
    
    /**
     * Handle clear filters action
     */
    function handleClear($app) {
        const data = $app.data('appData') || appData;
        
        // Clear all filter inputs
        $app.find('#agroepecas-filters-container select').val('');
        $app.find('#agroepecas-filters-container input').val('');
        
        // Reset to show all data
        data.currentData = data.allData;
        displayResults($app, data.allData);
        
        showMessage($app, 'Filtros limpos', 'info');
        
        console.log('🧹 Filtros limpos');
    }
    
    /**
     * Handle sync action
     */
    function handleSync($app) {
        const context = $app.data('appContext');
        
        if (!context.planilha) {
            showError($app, 'URL da planilha não configurada');
            return;
        }
        
        const $syncBtn = $app.find('#agroepecas-btn-sync');
        $syncBtn.prop('disabled', true).addClass('syncing').text('Sincronizando...');
        
        console.log('🔄 Iniciando sincronização...');
        
        // Note: This would need to be implemented on the server side
        // For now, just reload the data
        setTimeout(function() {
            loadData($app);
            $syncBtn.prop('disabled', false).removeClass('syncing').text('Sincronizar');
            showMessage($app, 'Sincronização concluída', 'success');
        }, 2000);
    }
    
    /**
     * Display results in table
     */
    function displayResults($app, data) {
        const context = $app.data('appContext');
        const $tableHead = $app.find('#agroepecas-table-head');
        const $tableBody = $app.find('#agroepecas-result-table');
        const $initialMessage = $app.find('#agroepecas-initial-message');
        const $noResults = $app.find('#agroepecas-no-results');
        const $tableContainer = $app.find('.agroepecas-table-container');
        
        // Hide messages
        $initialMessage.hide();
        $noResults.hide();
        
        if (!data || data.length === 0) {
            $tableContainer.hide();
            $noResults.show();
            return;
        }
        
        // Show table
        $tableContainer.show();
        
        // Define which columns to show in results based on app type
        let resultColumns = [];
        
        if (context.tipo === 'filtros') {
            // For filtros app, show these 4 columns
            resultColumns = ['aplicacao', 'nota', 'qtd', 'obs'];
        } else if (context.tipo === 'conversor') {
            // For conversor app, show conversion results
            resultColumns = ['sistema_origem', 'sistema_destino', 'valor_origem', 'valor_destino'];
        }
        
        // Build table header
        let headerHtml = '';
        const firstRow = data[0];
        
        // Check which result columns exist in the data
        const availableColumns = resultColumns.filter(col => firstRow.hasOwnProperty(col));
        
        availableColumns.forEach(function(fieldName) {
            headerHtml += `<th>${formatFieldLabel(fieldName)}</th>`;
        });
        
        // If no specific columns found, show all non-ID columns
        if (availableColumns.length === 0) {
            Object.keys(firstRow).forEach(function(key) {
                if (key !== 'id') {
                    headerHtml += `<th>${formatFieldLabel(key)}</th>`;
                }
            });
        }
        
        $tableHead.html(headerHtml);
        
        // Build table body
        let bodyHtml = '';
        data.forEach(function(row) {
            bodyHtml += '<tr>';
            
            if (availableColumns.length > 0) {
                // Show only specific columns
                availableColumns.forEach(function(fieldName) {
                    const value = row[fieldName] || '';
                    bodyHtml += `<td>${escapeHtml(value.toString())}</td>`;
                });
            } else {
                // Show all non-ID columns
                Object.keys(row).forEach(function(key) {
                    if (key !== 'id') {
                        const value = row[key] || '';
                        bodyHtml += `<td>${escapeHtml(value.toString())}</td>`;
                    }
                });
            }
            
            bodyHtml += '</tr>';
        });
        $tableBody.html(bodyHtml);
        
        console.log('📊 Tabela atualizada com', data.length, 'registros e colunas:', availableColumns);
    }
    
    /**
     * Utility functions
     */
    function getUniqueValues(data, field) {
        if (!data || !Array.isArray(data)) return [];
        
        const values = data.map(row => row[field])
            .filter(value => value != null && value.toString().trim())
            .map(value => value.toString().trim());
            
        return [...new Set(values)].sort();
    }
    
    function formatFieldLabel(fieldName) {
        const labels = {
            // Filter fields (6 filters)
            'marca': 'Marca',
            'linha': 'Linha',
            'motor': 'Motor',
            'tipo': 'Tipo',
            'modelo': 'Modelo',
            'modelo_motor': 'Modelo do Motor',
            
            // Result fields for filtros app (4 columns)
            'aplicacao': 'Aplicação',
            'nota': 'Nota',
            'qtd': 'QTD',
            'obs': 'OBS',
            
            // Converter fields
            'sistema_origem': 'Sistema de Origem',
            'sistema_destino': 'Sistema de Destino',
            'valor_origem': 'Valor de Origem',
            'valor_destino': 'Valor de Destino',
            
            // Legacy fields
            'categoria': 'Categoria',
            'codigo': 'Código',
            'compatibilidade': 'Compatibilidade'
        };
        
        return labels[fieldName] || fieldName.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
    }
    
    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    
    function showLoading($app) {
        $app.find('#agroepecas-loading').show();
        $app.find('#agroepecas-results-container > *:not(#agroepecas-loading)').hide();
    }
    
    function hideLoading($app) {
        $app.find('#agroepecas-loading').hide();
        $app.find('#agroepecas-results-container > *:not(#agroepecas-loading)').show();
    }
    
    function showMessage($app, message, type = 'info') {
        // Remove existing messages
        $app.find('.agroepecas-message').remove();
        
        const messageHtml = `
            <div class="agroepecas-message ${type}" style="display: none;">
                ${escapeHtml(message)}
            </div>
        `;
        
        $app.find('.agroepecas-results-section h2').after(messageHtml);
        $app.find('.agroepecas-message').fadeIn();
        
        // Auto-hide after 5 seconds
        setTimeout(function() {
            $app.find('.agroepecas-message').fadeOut(function() {
                $(this).remove();
            });
        }, 5000);
    }
    
    function showError($app, message) {
        showMessage($app, message, 'error');
        console.error('❌ Erro:', message);
    }
    
    // Global error handler
    $(document).ajaxError(function(event, xhr, settings, thrownError) {
        if (settings.url.includes('agroepecas')) {
            console.error('❌ Erro AJAX global:', {
                url: settings.url,
                status: xhr.status,
                error: thrownError,
                response: xhr.responseText
            });
        }
    });
    
    console.log('✅ AGRO&PEÇAS App JavaScript carregado completamente');
});